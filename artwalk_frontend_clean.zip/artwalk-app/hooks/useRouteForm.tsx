import React, { createContext, useContext, useState, ReactNode, useEffect } from "react";

type RouteFormData = {
  name: string;
  district: string;
  max_minutes: string;
  num_stops: string;
  styles?: string[];
};

type ArtworkEntry = {
  id: string;
  image: string;
  style?: string[]; // kommt aus JSON
  [key: string]: any;
};

type RouteFormContextType = {
  formData: RouteFormData;
  setFormData: (data: Partial<RouteFormData>) => void;
  resetForm: () => void;
  artworks: ArtworkEntry[];
};

const RouteFormContext = createContext<RouteFormContextType | undefined>(undefined);

export const RouteFormProvider = ({ children }: { children: ReactNode }) => {
  const [formData, setFormDataState] = useState<RouteFormData>({
    name: "",
    district: "",
    max_minutes: "",
    num_stops: "",
    styles: undefined,
  });

  const [artworks, setArtworks] = useState<ArtworkEntry[]>([]);

  const setFormData = (data: Partial<RouteFormData>) => {
    setFormDataState((prev) => ({ ...prev, ...data }));
  };

  const resetForm = () => {
    setFormDataState({
      name: "",
      district: "",
      max_minutes: "",
      num_stops: "",
      styles: undefined,
    });
    setArtworks([]);
  };

  useEffect(() => {
    const fetchArtworks = async () => {
      try {
        const res = await fetch(`${process.env.EXPO_PUBLIC_API_URL}/artworks`);
        const data = await res.json();
        setArtworks(data);
      } catch (err) {
        console.error("Fehler beim Laden der Artwork-Daten:", err);
      }
    };

    fetchArtworks();
  }, []);

  return (
    <RouteFormContext.Provider value={{ formData, setFormData, resetForm, artworks }}>
      {children}
    </RouteFormContext.Provider>
  );
};

export const useRouteForm = () => {
  const context = useContext(RouteFormContext);
  if (!context) {
    throw new Error("useRouteForm must be used within a RouteFormProvider");
  }
  return context;
};