import React, { useState } from "react";
import { ScrollView, Text, TouchableOpacity, StyleSheet, Image, View, Dimensions } from "react-native";
import { useRouteForm } from "../../hooks/useRouteForm";
import { useRouter } from "expo-router";

const CATEGORIES = [
  "Mural", "Graffiti", "Stencil", "Paste-up", "Calligraffiti", "3D Art",
  "Photorealistic", "Abstract", "Figurative", "Political", "Typography",
  "Urban Intervention", "Festival Art", "Portrait", "Animal Motif",
  "Cartoon Style", "Installation"
];

export default function StyleSelection() {
  const [selected, setSelected] = useState<string[]>([]);
  const { setFormData } = useRouteForm();
  const router = useRouter();

  const toggleStyle = (style: string) => {
    setSelected((prev) =>
      prev.includes(style) ? prev.filter((s) => s !== style) : [...prev, style]
    );
  };

  const handleStart = () => {
    setFormData({ styles: selected });
    router.push("/(tabs)/results"); // oder mapview oder was auch immer
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>
        Do you have favorite <Text style={{ fontStyle: "italic" }}>art styles</Text> or movements?
      </Text>

      <View style={styles.grid}>
        {CATEGORIES.map((style, index) => (
          <TouchableOpacity
            key={style}
            style={styles.item}
            onPress={() => toggleStyle(style)}
          >
            <Image
              source={require(`../../assets/styles/${index + 1}.jpg`)} // ← du benennst die Bilder selbst
              style={styles.image}
            />
            <View style={styles.overlay}>
              <Text style={styles.label}>{style}</Text>
              <Text style={styles.plus}>{selected.includes(style) ? "✓" : "+"}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.button} onPress={handleStart}>
        <Text style={styles.buttonText}>Start to Explore</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: "#FFFEFC",
    flexGrow: 1,
  },
  heading: {
    fontSize: 24,
    fontFamily: "InstrumentSerif-Regular",
    color: "#1D0C02",
    marginBottom: 16,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  item: {
    width: "48%",
    aspectRatio: 1,
    marginBottom: 16,
    borderRadius: 12,
    overflow: "hidden",
    position: "relative",
  },
  image: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  overlay: {
    position: "absolute",
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.45)",
    width: "100%",
    padding: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  label: {
    color: "#fff",
    fontFamily: "InstrumentSerif-Regular",
    fontSize: 14,
  },
  plus: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "600",
  },
  button: {
    backgroundColor: "#000",
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
    fontFamily: "InstrumentSans-Regular",
  },
});